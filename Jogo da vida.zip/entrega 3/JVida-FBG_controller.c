/*
Projeto Jogo da Vida
JVida-FBG

Grupo: João Victor Espanholi, Rodrigo Poinha, Gustavo Leite, Diogo Napolis

O  objetivo  do  projeto  é  criar  um  programa  em  C  para  simular  o  jogo  da  vida.  
Os indivíduos  vivem  numa  matriz  e o  programa  deve  gerar  a  geração  seguinte  a partir das regras previamente apresentadas. 
Cada posição da matriz é uma célula que pode ter um “O” (para representar um ser vivo) 
ou um espaço em brancoou um ponto para indicar “vazio” ou “morto”. 
*/

#include "JVida-FBG_model.h"
#include "JVida-FBG_controller.h"
#include <stdlib.h>

//Função para popular matriz
void gerarmundo()
 {
 
 int i,j;
 
 //popula a matriz do mundo
 
   for(i=0; i< tamanho; i++)        
        for(j=0; j< tamanho; j++)  
    mundo[i][j] = '.';
    
    
}

//Função switch-case para receber o retorno da opção das coordenadas da primeira geração
void Randandan(){
	
	int csm;
	
	do{
		
		csm= Menu();
		
		switch (csm){
		
		
		case 1: 
			apresentamundo();
			break;
		
		case 2:
			apresentamundo();
			primeiraGeracao();
			break;
		
		case 3:
			gerarmundo();
			CLLista();
			CLLista2();
			limpou();
			apresentamundo();
			break;
			
		case 4:
			ListaVivos();
			ListaMortos();
			break;
			
		case 5:
			Kinas();
			apresentamundo();
			Sanik();
			break;
		
		case 0:
			caso0();
			break;
			
		default:
			opcInval();
			break;
		
		}
	}while (csm!=0);
	
	
	
}


void AddLista(int ii, int jj)
{
	TipoCel *aux = malloc(sizeof(TipoCel));   //alocação dinâmica
	if (aux == NULL)
	{	
	Mackenzie();
	return;
	}
	//carrega os dados da célula:  ii e jj
	aux->lin = ii;
	aux->col = jj;
	//sempre inclui no início da listaporque neste caso a ordem não importa
	if(totvivo== 0)  //se a lista está vazia
	{
	pvivo = aux;
	pvivo->next = NULL;
	
	}
	else                //lista não vazia
	{
	aux->next = pvivo;
	pvivo = aux;  //o inicio da lista passa a ser a nova celula
	}
	totvivo++;
}

//A função a seguir é destinada para que conforme o usuário interaja com a função de alocar, o mesmo possa remover da lista os elementos que foram retirados
void excVivosLista(int ii, int jj)
{
	TipoCel *aux, *aux2;
	
	aux = pvivo;
	aux2 = aux;
	
	if (totvivo > 0)
	{
		while (aux->lin != ii || aux->col != jj)
		{
		aux2 = aux;
		aux = aux->next;
		}
		if (aux->lin == ii && aux->col == jj)
		{
			if (aux2 == aux)   //é o primeiro da lista
				pvivo = aux->next;
			else
				aux2->next = aux->next;
			free(aux);
				
		}totvivo--;
	}
}

//Destinamos a função a seguir para que, caso o usuario deseje limpar a matriz inteira
//sejam removidas as alocações dos elementos previamente feitos
void CLLista()
{
    TipoCel *aux;
    
    
    aux = pvivo;
	
	
    
    while(aux <= totvivo)
        {
        free(aux);
         aux = aux->next;
    	}
		
	totvivo=0;
    aux = aux->next;
    free(aux);
    

    printf("\n");
}

void CLLista2() //Necroterio dos vivos
{
    TipoCel *aux;

    
    aux = pmorto;
	
    if (totmorto>0){
	
    while(aux <= totmorto)
        {
        free(aux);
         aux = aux->next;
         
    	}
		totmorto=0;
	
    aux = aux->next;
    free(aux);
	

    printf("\n");
	}
}

void carrega1morto(int lin, int col){
	
	if ((lin>=0 && lin<tamanho) && (col>=0 && col<tamanho) && (mundo[lin][col]!='O') ){
		if (cursorcompara(lin,col) == 1)
		
			AddListaM(lin,col);
		
		
		
	}
	
	
}



//Carrega Mortos Vizinhos
void CarregaMVizinhos(int ii, int jj) {
	
	CLLista2();
	
	TipoCel *aux= pvivo;
	
	while(aux->next != NULL)
		{
			
		carrega1morto(aux->lin+1, aux->col+1);
		carrega1morto(aux->lin+1, aux->col-1);
		carrega1morto(aux->lin-1, aux->col+1);
		carrega1morto(aux->lin+1, aux->col);
		carrega1morto(aux->lin, aux->col+1);
		carrega1morto(aux->lin-1, aux->col);
		carrega1morto(aux->lin, aux->col-1);
		carrega1morto(aux->lin-1, aux->col-1);	
			
		aux=aux->next;
		}
		carrega1morto(aux->lin+1, aux->col+1);
		carrega1morto(aux->lin+1, aux->col-1);
		carrega1morto(aux->lin-1, aux->col+1);
		carrega1morto(aux->lin+1, aux->col);
		carrega1morto(aux->lin, aux->col+1);
		carrega1morto(aux->lin-1, aux->col);
		carrega1morto(aux->lin, aux->col-1);
		carrega1morto(aux->lin-1, aux->col-1);
		
		
	

}

//Função para adicionar seres mortos
void AddListaM(int ii, int jj)
{
	
	TipoCel *aux = malloc(sizeof(TipoCel));   //alocação dinâmica
	if (aux == NULL)
	{	
	Mackenzie();
	return;
	}
	//carrega os dados da célula:  ii e jj
	aux->lin = ii;
	aux->col = jj;
	//sempre inclui no início da listaporque neste caso a ordem não importa
	//se a lista está vazia
	if(totmorto== 0)  
	{
	pmorto = aux;
	pmorto->next = NULL;
	
	}
	else                
	{
	aux->next = pmorto;
	pmorto = aux;  //o inicio da lista passa a ser a nova celula
	}
	totmorto++;
}

//Esta função é destinada a comparar os espaços disponiveis da matriz e ver se já possuem mortos em determinadas posições
int cursorcompara(int lin, int col){
	
	TipoCel *aux= pmorto;
	
	if(totmorto==0)
	return 1;
	
	else{
	
	
	while(aux->next != NULL)
	{
		if ((aux->col == col) && (aux->lin == lin))
			return 0;
			
		aux=aux->next;
		
	}
	if ((aux->col == col) && (aux->lin == lin))
		return 0;
	
	else 
		return 1;
	}
}


