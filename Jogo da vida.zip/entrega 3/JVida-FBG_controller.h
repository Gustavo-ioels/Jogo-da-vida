/*
Projeto Jogo da Vida
JVida-FBG

Grupo: João Victor Espanholi, Rodrigo Poinha, Gustavo Leite, Diogo Napolis

O  objetivo  do  projeto  é  criar  um  programa  em  C  para  simular  o  jogo  da  vida.  
Os indivíduos  vivem  numa  matriz  e o  programa  deve  gerar  a  geração  seguinte  a partir das regras previamente apresentadas. 
Cada posição da matriz é uma célula que pode ter um “O” (para representar um ser vivo) 
ou um espaço em brancoou um ponto para indicar “vazio” ou “morto”. 
*/

void gerarmundo();

void Randandan();

void AddLista(int ii, int jj);

void excVivosLista(int ii, int jj);

void CLLista();

void CLLista2();

void carrega1morto(int lin, int col);

void CarregaMVizinhos(int ii, int jj);

void AddListaM(int ii, int jj);

int cursorcompara(int lin, int col);