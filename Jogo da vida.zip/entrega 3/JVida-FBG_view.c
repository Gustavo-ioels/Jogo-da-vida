/*
Projeto Jogo da Vida
JVida-FBG

Grupo: João Victor Espanholi, Rodrigo Poinha, Gustavo Leite, Diogo Napolis

O  objetivo  do  projeto  é  criar  um  programa  em  C  para  simular  o  jogo  da  vida.  
Os indivíduos  vivem  numa  matriz  e o  programa  deve  gerar  a  geração  seguinte  a partir das regras previamente apresentadas. 
Cada posição da matriz é uma célula que pode ter um “O” (para representar um ser vivo) 
ou um espaço em brancoou um ponto para indicar “vazio” ou “morto”. 
*/

#include "JVida-FBG_model.h"
#include "JVida-FBG_controller.h"
#include <stdio.h>

int Menu(){
	
	int opc;
	
		printf("\n Jogo da Vida FBG");
		printf("\n 1 - Apresentar mundo");
        printf("\n 2 - Definir os seres vivos da primeira geracao");
        printf("\n 3 - Limpar a matriz do mundo");
        printf("\n 4 - Mostrar listas");
        printf("\n 5 - Mostrar/esconde as celulas mortas-vizinhas");
        printf("\n 0 - Sair\n");
        scanf("%d",&opc);
	
	return(opc);
}


void tamanhoMundo(){
		
		
	do{
	
	printf("digite o tamanho desejado do mundo (min:10, max:60 )\n");
	scanf("%d", &tamanho);
	
	//testamos o valor minimo e maximo de alocação da matriz
	//caso seja um valor entre 10 e 60, então o programa seguirá
	
	if (tamanho<10 || tamanho>60) { 
        	printf("O tamanho de mundo exigido esta fora dos parametros pre-requisitados\n"); 
        	continue;
    }
    else
    	gerarmundo();
	
	}while (tamanho<10 || tamanho>60);
}

void primeiraGeracao(){
	
	int i, j;
	int ventiladorCromado;
	
	do 
	{

    	printf("\nDigite a coordenada desejada, separado por virgula (-1,-1 para sair): ");
    	scanf("%d,%d", &i, &j); 
    
    	if (i!=-1 && j!=-1){
    		
    		if (i<0 || i>=tamanho || j<0 || j>=tamanho){ 
        	printf("A posicao especificada nao existe no mundo \n"); 
        	continue;
        	}
		} else 
		break;
    
    	
    
    	//criamos tal condição pois há a possibilidade que o usuário tente digitar uma coordenada já ocupada
      	if (mundo[i][j]=='O') 
		{
     		 printf("Ja ha um individuo nesta posicao, deseja exclui-lo? (0 nao, 1 sim) \n");
     		 scanf("%d", &ventiladorCromado);
     		 
     		 if (ventiladorCromado==1)
			 {
			 mundo[i][j]='.';
     		 excVivosLista(i, j);
     		 apresentamundo();
     		 }
			 	
		}else{
	 		mundo[i][j] = 'O';   
      		printf("Individuo posicionado com sucesso!\n");
      		AddLista(i,j);
      		apresentamundo();
      		CarregaMVizinhos(i, j);
		}
   
	}
	while (i!=-1 || j!=-1);
    
} 	

//Função de impressão da matriz com seus respectivos elementos
void apresentamundo(){
	
	int i,j;
	
	
	printf("        ");
    for(j = 0; j < tamanho; j++)
        printf("%2d ",j);
    printf("\n\n");

    for(i=0; i < tamanho ; i++)
    {
    printf("%2d :\t",i);
    for(j=0; j < tamanho; j++)
        printf(" %c ",mundo[i][j]);
    printf("\n");
    }


}

void caso0 (){
	
	printf("Foi de base um dos grandes \n");
	
}

void limpou(){
	printf("Mundo limpo com sucesso! \n");
}

void opcInval(){
	printf("Opcao invalida \n");
}

void Mackenzie(){
	printf("Sem espaço na memoria para inclusao de celula viva\n");
}


void ListaVivos()
{
	TipoCel *aux;	//define um ponteiro auxiliar
	aux = pvivo;	//inicializa esse ponteiro auxiliar
	if (totvivo > 0)
	{
		printf("Lista dos vivos:");
		NewLine();
		
	while(aux->next != NULL)
		{
		printf("%d,%d   ", aux->lin, aux->col);
		aux = aux->next;	//caminha para o próximo ponteiro
		}
		printf("%d,%d   ", aux->lin, aux->col);//mostra a ultima celula
	}
		
		printf("\n");
}

void ListaMortos(){
	
	TipoCel *aux;	//define um ponteiro auxiliar
	aux = pmorto;	//inicializa esse ponteiro auxiliar
	if (totmorto > 0)
	{
		printf("Lista dos mortos:");
		NewLine();	
		
	while(aux->next != NULL)
		{
		printf("%d,%d   ", aux->lin, aux->col);
		aux = aux->next;	//caminha para o próximo ponteiro
		}
		printf("%d,%d   ", aux->lin, aux->col);//mostra a ultima celula
	}
		
		printf("\n");
}

void Kinas(){
		
	TipoCel *aux;	//define um ponteiro auxiliar
	aux = pmorto;	//inicializa esse ponteiro auxiliar
	if (totmorto > 0)
	{
	while(aux->next != NULL)
		{
		mundo[aux->lin][aux->col] = '+';
		aux = aux->next;	//caminha para o próximo ponteiro
		}
		mundo[aux->lin][aux->col] = '+';//mostra a ultima celula
	}
		
		printf("\n");
}

void Sanik(){
		
	TipoCel *aux;	//define um ponteiro auxiliar
	aux = pmorto;	//inicializa esse ponteiro auxiliar
	if (totmorto > 0)
	{
	while(aux->next != NULL)
		{
		mundo[aux->lin][aux->col] = '.';
		aux = aux->next;	//caminha para o próximo ponteiro
		}
		mundo[aux->lin][aux->col] = '.';//mostra a ultima celula
	}
		
		printf("\n");
}


void NewLine(){
	printf("\n");
}

